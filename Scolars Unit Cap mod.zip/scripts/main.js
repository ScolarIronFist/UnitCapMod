Blocks.coreShard.unitCapModifier = 275;
Blocks.coreFoundation.unitCapModifier = 750;
Blocks.coreNucleus.unitCapModifier = 1500;